﻿using System;
using EPiServer;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using GSALib.GSA;

namespace Helsetilsynet
{
    public partial class NotFound404 : BVNetwork.FileNotFound.NotFoundBase
    {
        private static string _searchUrl = "{0}&quicksearchquery={1}";
        protected global::System.Web.UI.WebControls.TextBox SearchText;
        //protected global::System.Web.UI.WebControls.Button SearchButton;

        //protected override void OnLoad(System.EventArgs e)
        //{
        //    base.OnLoad(e);
        //}

        /// <summary>
        /// Redirects to the search result page
        /// </summary>
        protected void Search_Click(object sender, EventArgs e)
        {
            string searchText = HttpUtility.UrlEncode(SearchText.Text.Trim());
            HttpContext.Current.Response.Redirect(string.Format(_searchUrl, "http://helsetilsynet.no/no/ts/sokeside/?", searchText));
        }

    }
}
