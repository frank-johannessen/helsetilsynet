using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using EPiServer;
using EPiServer.WebControls;
using EPiServer.Core;
using EPiServer.DataAccess;
using EPiServer.PlugIn;
using EPiServer.Security;

namespace development.Plugins
{

	/// <summary>
	///		Summary description for EmergencyControl.
	/// </summary>

	[GuiPlugIn(
		 DisplayName="Snarveiliste",
		 Description="Viser liste over brukte snarveier",
		 Area=PlugInArea.AdminMenu, 
		 RequiredAccess=AccessLevel.Administer,	 
		 Url="~/Class/Plugin/ShortcutList.aspx")
	]
	public class ShortcutList : SimplePage //, ICustomPlugInLoader
	{
		protected MakingWaves.MakingCode.EPiServer.WebControls.PageList SiteList;		
		protected System.Web.UI.WebControls.Panel SystemMessagePanel;
		protected System.Web.UI.WebControls.Label SystemMessage;
		protected System.Web.UI.WebControls.LinkButton AddShortcut;
		
		protected EPiServer.WebControls.Property NewPageLink;
		protected EPiServer.WebControls.Property NewPageExternalURL;
		private PageDataCollection pages = new PageDataCollection();
		private EPiServer.Core.PageReference editPageReference;
	
		private void Page_Load(object sender, System.EventArgs e)
		{						
			SystemMessagePanel.Visible = false;

			if (!IsPostBack)
			{
				if (Request.QueryString.Get("id") == null)
				{
					NewPageExternalURL.InnerProperty.Value = null;
					NewPageLink.InnerProperty.Value = null;												
				}
			}

			PopulateShortcutList();
		}

		private void FindPagesWithShortcuts(PageReference startAt)
		{
			PageData pd = GetPage(startAt);

			if (pd.Property["PageExternalURL"] != null && pd.Property["PageExternalURL"].ToString() != String.Empty)			
				pages.Add(pd);
			
			foreach (PageData child in GetChildren(pd.PageLink))
			{
				FindPagesWithShortcuts(child.PageLink);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
			this.AddShortcut.Click += new EventHandler(AddShortcut_Click);
		}
		#endregion

		private void AddShortcut_Click(object sender, EventArgs e)
		{
			if (NewPageExternalURL.PropertyValue == null)
			{
				WriteSystemMessage("Navn p� snarvei er ikke korrekt utfyllt.", true);
				return;
			}	

			if (NewPageLink.PropertyValue == null)
			{
				WriteSystemMessage("Du har ikke valgt noen side � opprette snarvei til.", true);
				return;
			}	

			PageData pd = GetPage((PageReference)NewPageLink.PropertyValue);

			if (pd["PageExternalURL"] != null)
			{
				WriteSystemMessage("Siden har alt definert en snarvei. Det er kun mulig � opprette en snarvei pr. side. Om du �nsker flere alias kan du opprette nye sider som peker til den opprinnelige siden. Disse nye sidene kan ha forskjellige snarveier.", true);
			}

			try 
			{
				pd["PageExternalURL"] = NewPageExternalURL.PropertyValue;

				Global.EPDataFactory.Save(pd, EPiServer.DataAccess.SaveAction.Publish);
				
				WriteSystemMessage("Ny snarvei lagret.", false);
				
				PopulateShortcutList();		

				NewPageExternalURL.InnerProperty.Value = null;
				NewPageLink.InnerProperty.Value = null;	
			} 
			catch (Exception ex)
			{
				WriteSystemMessage("Lagring av snarvei feilet. " + ex.Message, true);
			}
	
		}
		
		private void PopulateShortcutList()
		{
			
			pages = new PageDataCollection();
			FindPagesWithShortcuts(Global.EPConfig.StartPage);

			SiteList.DataSource = pages;
			SiteList.DataBind();
		}

		private void WriteSystemMessage(string message, bool isError)
		{
			SystemMessagePanel.Visible = true;
			SystemMessage.Text = message;
			if (isError)
				SystemMessage.ForeColor = Color.Red;
			else
				SystemMessage.ForeColor = Color.Black;

		}

		protected void EditShortcut_Click(object sender, CommandEventArgs e)
		{
			int pageID = Convert.ToInt32(e.CommandArgument);

			try 
			{
				editPageReference = PageReference.EmptyReference;

				if (e.CommandName == "Remove") 
				{				
					PageData pd = GetPage(new PageReference(pageID));
					pd["PageExternalURL"] = null;

					Global.EPDataFactory.Save(pd, EPiServer.DataAccess.SaveAction.Publish);
				
					WriteSystemMessage("Snarvei slettet.", false);
					NewPageExternalURL.InnerProperty.Value = null;
					NewPageLink.InnerProperty.Value = null;	
				}

				PopulateShortcutList();		
				
			} 
			catch (Exception ex)
			{
				WriteSystemMessage("Sletting/endring av snarvei feilet. " + ex.Message, true);
			}
		}		
	}
}