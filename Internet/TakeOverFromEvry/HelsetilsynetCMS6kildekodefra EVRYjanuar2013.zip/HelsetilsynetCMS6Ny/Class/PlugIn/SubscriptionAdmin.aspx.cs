using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Runtime.Remoting;
using System.Text;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

using EPiServer;
using EPiServer.Core;
using EPiServer.Filters;
using System.Collections.Specialized;
using EPiServer.DataAccess;
using EPiServer.DataAbstraction;
using EPiServer.Security;
using EPiServer.Personalization;
using EPiServer.PlugIn;

using EPiServer.WebControls;
using System.Web.Security;
using System.Security.Principal;

namespace development.Class.PlugIn
{
	/// <summary>
	/// Brukergrensesnitt for administrering av abbonnementsfunksjonen i EPiServer
	/// </summary>
	/// 
	[GuiPlugIn(
		 DisplayName="Abonnement admin",
		 Description="Administrering av nyhetsbrev",
		 Area=PlugInArea.AdminMenu ,
		 Url="~/Class/Plugin/SubscriptionAdmin.aspx", 
		 LanguagePath="/myshop/plugin/ShopPluginTree")]
	public class SubscriptionAdmin : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dgSubscription;
		protected System.Web.UI.WebControls.Panel EditArea;
		protected System.Web.UI.WebControls.CheckBoxList CheckBoxList1;
		protected System.Web.UI.WebControls.Button btnSave;
		protected System.Web.UI.WebControls.TextBox txtEmail;
		protected System.Web.UI.WebControls.DropDownList Interval2;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Button btnNew;
		protected System.Web.UI.WebControls.Label lblId;
		protected EPiServer.WebControls.Translate Translate4;
		protected InputPassword	Password;
		protected Label			ErrorMessage;
		protected EPiServer.WebControls.Translate Translate6;
		protected Panel			SaveFailed;
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			BindDataSet();
			EditArea.Visible=false;
			SaveFailed.Visible=false;
		}

		private void dgSubscription_DeleteCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			int sid=Convert.ToInt32(e.Item.Cells[2].Text);
			UserSid _user =UserSid.Load(sid);
			_user.Delete();
			BindDataSet();
			

		}

		private void dgSubscription_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			

		}

		private void dgSubscription_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			//EditArea.Visible=true;
			EditArea.Visible=true;
			CheckBoxList1.Items.Clear();
			PageDataCollection pageCol=Class.MyEPiServer.PageCriteriaSearch.PropertySearchBool("EPSUBSCRIBE",true);
			int sid=Convert.ToInt32(dgSubscription.SelectedItem.Cells[2].Text);
			UserSid _user =UserSid.Load(sid);
			txtEmail.Text=_user.Email;
			lblId.Text=_user.ID.ToString();
			PersonalizedData perz= PersonalizedData.Load(_user.ID);
			SubscriptionInfo info= new SubscriptionInfo(perz);
			
			foreach (PageData page in pageCol)
			{
				System.Web.UI.WebControls.ListItem listItem = new ListItem(page.PageName,page.PageLink.ID.ToString());
				if(info.IsSubscribingTo(page.PageLink))
					listItem.Selected=true;
				CheckBoxList1.Items.Add(listItem);
			}

			
			System.Diagnostics.Trace.WriteLine("Set select");
			
			for(int i = 0; i<Interval2.Items.Count;i++)
			{
				if(Interval2.Items[i].Value==info.Interval.ToString())
				{
					Interval2.SelectedIndex=i;
				}
			}
			
			
			CheckBoxList1.DataBind();
		}


		private void btnSave_Click(object sender, System.EventArgs e)
		{
			UserSid _user=null;
			if(lblId.Text!="")
			{
				_user=UserSid.Load(Convert.ToInt32(lblId.Text));
			}
			else
			{
				_user=newUser();
				if (_user==null)
				{
					EditArea.Visible=true;
					return;
				}
			}
			PersonalizedData perz= PersonalizedData.Load(_user.ID);
			SubscriptionInfo info= new SubscriptionInfo(perz);
			PageDataCollection pageCol=Class.MyEPiServer.PageCriteriaSearch.PropertySearchBool("EPSUBSCRIBE",true);
			foreach(PageData page in pageCol)
			{
				if(info.IsSubscribingTo(page.PageLink))
					info.UnSubscribe(page.PageLink);
			}
			
			for(int i=0; i<CheckBoxList1.Items.Count;i++)
			{
				
				if(CheckBoxList1.Items[i].Selected)
				{
					EPiServer.Core.PageReference pageRef= new PageReference(Convert.ToInt32(CheckBoxList1.Items[i].Value));
					info.SubscribeTo(pageRef);
				}
			}
			info.Interval = Int32.Parse(Interval2.SelectedItem.Value);
			perz.Save();
			if(_user.Email != txtEmail.Text)
			{
				_user.Email = txtEmail.Text;
				_user.Name = txtEmail.Text;
				_user.Save();
			}
			if(lblId.Text!="")
			{
				//if(Password.FirstPassword==Password.SecondPassword)
					_user.Password=txtEmail.Text;
				/*else 
				{
					ErrorOccured(Global.EPLang.Translate("/admin/edituser/passwordmismatch"));
					return;
				}*/
			}

			BindDataSet();
			EditArea.Visible=false;
			
			
		}

		private UserSid newUser()
		{
			UserSid _user;
			_user = new UserSid(SecurityIdentityType.ExtranetUser);
			_user.Name=txtEmail.Text;
			_user.Email=txtEmail.Text;
			_user.Password=txtEmail.Text;
			_user.MemberOfGroups.Add(GroupSid.Load(Convert.ToInt32(EPiServer.Global.EPConfig["EPnDefaultGroup"].ToString())));
			_user.Active = Convert.ToBoolean(EPiServer.Global.EPConfig["EPfAutoActivateUser"].ToString());
			PersonalizedData perz= PersonalizedData.Load(_user.ID);
			SubscriptionInfo info= new SubscriptionInfo(perz);
			/*if(Password.FirstPassword != Password.SecondPassword)
			{
				ErrorOccured(Global.EPLang.Translate("/admin/edituser/passwordmismatch"));
				return null;
			}*/
			//else
			{
				try
				{
					_user.Save();
				}
				catch
				{
				}
			}
			return _user;
		}

		private void BindDataSet()
		{
			PageDataCollection pageCol=Class.MyEPiServer.PageCriteriaSearch.PropertySearchBool("EPSUBSCRIBE",true);
			
			DataSet AbonnentDS = new DataSet();

			AbonnentDS.Tables.Add(new DataTable());
			AbonnentDS.Tables[0].Columns.Add("id");

			AbonnentDS.Tables[0].Columns.Add("E-post");

			//AbonnentDS.Tables[0].Columns.Add("Abonnerer");//

			foreach (PageData page in pageCol)
			{
				AbonnentDS.Tables[0].Columns.Add(page.PageName);
			}

			
			
			SidCollection sidCol= GroupSid.LoadGroup("abonnement").GroupMembers;
			
			EPiServer.WebControls.SubscriptionList subList = new EPiServer.WebControls.SubscriptionList();
			
			
			ArrayList array = new ArrayList();
			foreach(UserSid sid in sidCol)
			{	
				UserSid _user =UserSid.Load(sid.ID);
				PersonalizedData perz= PersonalizedData.Load(sid.ID);
				SubscriptionInfo info= new SubscriptionInfo(perz);
				PageReference[] pageRefCol= info.ListSubscriptions();
				string pages="";
				foreach(PageReference pageRef in pageRefCol)
				{
					PageData pageData= Global.EPDataFactory.GetPage(pageRef);
					pages += pageData.PageName+" ";
				}
				DataRow rad = AbonnentDS.Tables[0].NewRow();
				rad["E-post"] = _user.Email;
				rad["id"] = _user.ID;
				foreach (PageData page in pageCol)
				{
					if(info.IsSubscribingTo(page.PageLink))
					{
						rad[page.PageName] = "[x]";
					}
					else
					{
						rad[page.PageName] = "[&nbsp;&nbsp;]";
					}
				}

				//rad["abonnerer"] = pages;
				AbonnentDS.Tables[0].Rows.Add(rad);


			}
			dgSubscription.DataSource=AbonnentDS.Tables[0];//GroupSid.LoadGroup("abonnement").GroupMembers;
			dgSubscription.DataBind();
		}

		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			EditArea.Visible=false;
		}

		protected void btnNew_Click(object sender, System.EventArgs e)
		{
			txtEmail.Text="";
			lblId.Text="";
			//Password.Collapsed = false;
			EditArea.Visible=true;
			CheckBoxList1.Items.Clear();
			PageDataCollection pageCol=Class.MyEPiServer.PageCriteriaSearch.PropertySearchBool("EPSUBSCRIBE",true);
			
			
			foreach (PageData page in pageCol)
			{
				System.Web.UI.WebControls.ListItem listItem = new ListItem(page.PageName,page.PageLink.ID.ToString());
			
				CheckBoxList1.Items.Add(listItem);
			}
			
			CheckBoxList1.DataBind();
		
		}

		protected void ErrorOccured(string errorMessage)
		{
			SaveFailed.Visible		= true;
			//			SaveSucceded.Visible	= false;			
			ErrorMessage.Text		= errorMessage;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dgSubscription.DeleteCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.dgSubscription_DeleteCommand);
			this.dgSubscription.SelectedIndexChanged += new System.EventHandler(this.dgSubscription_SelectedIndexChanged);
			this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);


		}
		#endregion
	}
}
