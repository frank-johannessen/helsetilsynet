﻿var pagingIndex = 0;

function stepPager(index) {

	// Get selected link and the link that is going to be selected
	var oldLink = $('#pagerlink' + (pagingIndex));
	var newLink = $('#pagerlink' + index);

	// Hide paging content, step pagingIndex and show new paging content
	if (pagingIndex != null) {
		hideContainer('paging' + pagingIndex);
		pagingIndex = index;
		showContainer('paging' + pagingIndex);
	}
	
	// Set and remove selected class from links
	if (oldLink != null && newLink != null) {
		newLink.addClass("selected");
		oldLink.removeClass("selected");
	}
}

function initTables() {
    // Close all active TineMce
    closeAllAnsweringContainers();
	// Get all answered questions
	getQuestions('answered', 'true', 'false', 'false', 'false');
	// Get all unanswered questions
	getQuestions('notanswered', 'false', 'false', 'false', 'false');
	// Get all thrown questions
	getQuestions('thrown', 'false', 'true', 'false', 'false');
	// Get all questions on hold
	getQuestions('onhold', 'false', 'false', 'true', 'false');
	// Get all questions that is being answered
	getIsAnsweredQuestions('isanswering');
}

function showHide(showid, hideid) {
    // Get vaiables
    var showContainer = $('#' + showid);
    var hideContainer = $('#' + hideid);
    if (showContainer != null && hideContainer != null) {
        // Show
        showContainer.show();

        // Hide
        hideContainer.hide();
    }
}

function showHide(toggleId) {
    // Get vaiables
    var toggleContainer = $('#' + toggleId);
    if (toggleContainer != null) {
        // Show
        toggleContainer.toggle();
       }
}

function showContainer(toggleId) {
   	// Get vaiable to show
   	var toggleContainer = $('#' + toggleId);
   	if (toggleContainer != null) {
   		// Show
   		toggleContainer.show();
   	}
}

function hideContainer(toggleId) {
   	// Get vaiable to hide
   	var toggleContainer = $('#' + toggleId);
   	if (toggleContainer != null) {
   		// Hide
   		toggleContainer.hide();
   	}
}

function removeContainer(removeId) {
	// Get vaiable to remove
	var removeContainer = $('#' + removeId);
	if (removeContainer != null) {
		// Remove
		removeContainer.remove();
	}
}

// Empty all input type text or textarea fields inside a container
function clearContent(containerId) {
	$('#' + containerId + ' input[type = "text"], textarea').each(function() {
		$(this).val('');
	});
}

function toggleQuestionContainers(openId) {
    // Close all questions put to answering
    closeAllAnsweringContainers();
    
	// Close answered questions
	hideContainer('answeredquestions');

	// Close notanswered questions
	hideContainer('notansweredquestions');

	// Close thrown questions
	hideContainer('thrownquestions');

	// Close on hold questions
	hideContainer('onholdquestions');

	// Close on hold questions that is answering
	hideContainer('isandweredquestions');

	// Open the requested questions container
	showContainer(openId);
}

function closeAllAnsweringContainers() {
    $(".Edit").each(function() {
        if ($(this).css("display") == "block") {
            var id = $(this).attr('id');
            var idArray = id.split('_');
            if (idArray.length > 1) {
                var containerId = 'throwquestion_' + idArray[1];
                var answerId = 'answerquestion_' + idArray[1];
                //Unload the editor
                var id = containerId + 'aarea';
                if (tinyMCE.getInstanceById(id) != null)
                { tinyMCE.execCommand('mceRemoveControl', false, id); }
                //Cancel the answer and witch puts the status to "normal"
                cancelAnswer(containerId, idArray[1], answerId);
                }
            }
        }
    );
}

function openTinyMce(textareaId) {
    //if (tinyMCE.getInstanceById(textareaId) != null) {
        tinyMCE.execCommand('mceAddControl', false, textareaId)
    //}
}

function saveAndCloseTinyMce(textareaId) {
    if (tinyMCE.getInstanceById(textareaId) != null) {
        tinyMCE.triggerSave();
        tinyMCE.execCommand('mceRemoveControl', false, textareaId)
    }
}

function closeTinyMce(textareaId) {
    if (tinyMCE.getInstanceById(textareaId) != null) {
        tinyMCE.execCommand('mceRemoveControl', false, textareaId)
    }
}

function hideButtons(containerId) {
    var fullContainerId = '#' + containerId + ' ul';
    $(fullContainerId).hide();
}

function openAllQuestionsContainers() {
    // Close all questions put to answering
    closeAllAnsweringContainers();
    
	// Open answered questions
	showContainer('answeredquestions');

	// Open notanswered questions
	showContainer('notansweredquestions');

	// Open thrown questions
	showContainer('thrownquestions');

	// Open on hold questions
	showContainer('onholdquestions');
	
	// Close on hold questions that is answering
	showContainer('isandweredquestions');
}

function getIsAnsweredQuestions(divid) {	
   	$.ajax({
   	url: "/EPiCode/Netmeeting/Ws/GetIsAnsweringQuestions.ashx?netmeetingId=" + netmeetingId + "&currentCulture=" + currentCulture,
   		type: "POST",
   		data: '{}',   		
   		dataType: "text",
   		success: function(data, textStatus) {
   			// Fill div container			
   			var divContainer = $('#' + divid);
   			if (divContainer != null) {
   				// Empty the container
   				divContainer.empty();
   				// Add to div container
   				divContainer.append(data);
   			}
   			return false;   			
   		}
   	});
   	return false;
   }

   function getQuestions(divid, isAnswered, isThrown, isOnHold, isView) {       
	$.ajax({
	url: "/EPiCode/Netmeeting/Ws/GetQuestions.ashx?netmeetingId=" + netmeetingId + "&isAnswered=" +
		    isAnswered + "&isThrown=" + isThrown + "&isOnHold=" + isOnHold + "&pagingIndex=" + pagingIndex + "&isView=" + isView + "&currentCulture=" + currentCulture,
		type: "POST",
		data: '{}',
		dataType: "text",
		success: function(data, textStatus) {
			// Fill div container			
			var divContainer = $('#' + divid);
			if (divContainer != null) {
				// Empty the container
				divContainer.empty();
				divContainer.append(data);				
			}
			return false;
		}
	});
   	return false;
}

// Opens the answercontainer for a question
function openAnswerContainer(containerId, questionId, answerId, isAnswered, isThrown, isOnHold, isAnswering) {
    $.ajax({
        //Check that the question is still in the same status before processing further
    url: "/EPiCode/Netmeeting/Ws/CheckStatus.ashx?questionId=" + questionId + "&isAnswered=" + isAnswered + "&isThrown=" + isThrown + "&isOnHold=" + isOnHold + "&isAnswering=" + isAnswering + "&currentCulture=" + currentCulture,
        type: "POST",
        data: '{}',
        dataType: "text",
        success: function(data, textStatus) {
            $.ajax({
            url: "/EPiCode/Netmeeting/Ws/AnsweringQuestion.ashx?questionId=" + questionId + "&isAnswering=true" + "&currentCulture=" + currentCulture,
                type: "POST",
                data: "{}",
                dataType: "text",
                success: function(data, textStatus) {
                    // Show answer container
                    showContainer(answerId);
                    return false;
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert('set answering not ok: ' + XMLHttpRequest.responseText);
                    return false;
                }
            });
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            //clearInterval(intervalId);
			alert(XMLHttpRequest.responseText);
            initTables();
        }
    });
}

function sendAnswer(containerId, questionId, answerId, responseId) {
    saveAndCloseTinyMce(containerId);
    $.ajax({
    url: "/EPiCode/Netmeeting/Ws/AnswerQuestion.ashx" + "?currentCulture=" + currentCulture,
        type: "POST",
        data: "questionIdStr=" + questionId + "&netmeetingIdStr=" + netmeetingId + "&strTitle=" + encodeURIComponent($('#' + answerId + ' .title').val()) + "&strQuestion=" + encodeURIComponent($('#' + answerId + ' .question').val()) + "&strAnswer=" + encodeURIComponent($('#' + answerId + ' .answer').val()),
        dataType: "text",
        success: function(data, textStatus) {
            // Get scroll position
            var x = $(window).scrollTop();
            // Clear content in answer container and close it.
            clearContent(answerId);
            hideContainer(answerId);
            // Fill the question containers again and set scroll position.
            initTables();
            $(window).scrollTop(x);
            return false;
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            // Display error message to the user
            var responseContainer = $('#' + responseId);
            if (responseContainer != null) {
                responseContainer.empty();
                responseContainer.append(XMLHttpRequest.responseText);
                responseContainer.show();
            }
            return false;
        }
    });
    return false;
}

function cancelAnswer(containerId, questionId, answerId) {
	$.ajax({
	url: "/EPiCode/Netmeeting/Ws/AnsweringQuestion.ashx?questionId=" + questionId + "&isAnswering=false" + "&currentCulture=" + currentCulture,
		type: "POST",
		data: "{}",
		dataType: "text",
		success: function(data, textStatus) {
			// Get scroll position
			var x = $(window).scrollTop();
			// Clear content in answer container and close it.
			clearContent(answerId);
			hideContainer(answerId);
			// Fill the question containers again and set scroll position.
			initTables();
			$(window).scrollTop(x);
			return false;
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			alert('noe gikk galt: ' + XMLHttpRequest.responseText);
			return false;
		}
	});
   	return false;
}

// Throws a question
function throwQuestion(containerId, questionId, isAnswered, isThrown, isOnHold, isAnswering, clearCache) {
	$.ajax({
		//Check that the question is still in the same status before processing further
	url: "/EPiCode/Netmeeting/Ws/CheckStatus.ashx?questionId=" + questionId + "&isAnswered=" + isAnswered + "&isThrown=" + isThrown + "&isOnHold=" + isOnHold + "&isAnswering=" + isAnswering + "&currentCulture=" + currentCulture,
		type: "POST",
		data: '{}',
		dataType: "text",
		success: function(data, textStatus) {
			$.ajax({
			url: "/EPiCode/Netmeeting/Ws/ThrowQuestion.ashx?questionId=" + questionId + "&clearCache=" + clearCache + "&netmeetingId=" + netmeetingId + "&currentCulture=" + currentCulture,
				type: "POST",
				data: "{}",
				dataType: "text",
				success: function(data, textStatus) {
					removeContainer(containerId);
					initTables();
					return false;
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					alert('throw not ok: ' + XMLHttpRequest.responseText);
					initTables();
					return false;
				}
			});
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			//clearInterval(intervalId);
			alert(XMLHttpRequest.responseText);
			initTables();
		}
	});
}

// Restores a thrown question
function restoreQuestion(containerId, questionId, isAnswered, isThrown, isOnHold, isAnswering) {
    $.ajax({
        //Check that the question is still in the same status before processing further
    url: "/EPiCode/Netmeeting/Ws/CheckStatus.ashx?questionId=" + questionId + "&isAnswered=" + isAnswered + "&isThrown=" + isThrown + "&isOnHold=" + isOnHold + "&isAnswering=" + isAnswering + "&currentCulture=" + currentCulture,
        type: "POST",
        data: '{}',
        dataType: "text",
        success: function(data, textStatus) {
            $.ajax({
            url: "/EPiCode/Netmeeting/Ws/RestoreQuestion.ashx?questionId=" + questionId + "&currentCulture=" + currentCulture,
                type: "POST",
                data: "{}",
                dataType: "text",
                success: function(data, textStatus) {
                    removeContainer(containerId);
                    initTables();
                    return false;
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert('restore not ok: ' + XMLHttpRequest.responseText);
                    initTables();
                    return false;
                }
            });
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            //clearInterval(intervalId);
			alert(XMLHttpRequest.responseText);
            initTables();
        }
    });
}

// Restores a thrown question
function restoreQuestionIsAnswering(containerId, questionId) {
    $.ajax({
        //Check that the question is still in the same status before processing further
        //Need to use CheckStatusIsAnswering since we dont know the other flags (ex. isOnHold, isThrown, etc.)
    url: "/EPiCode/Netmeeting/Ws/CheckStatusIsAnswering.ashx?questionId=" + questionId + "&currentCulture=" + currentCulture,
        type: "POST",
        data: '{}',
        dataType: "text",
        success: function(data, textStatus) {
            $.ajax({
            url: "/EPiCode/Netmeeting/Ws/RestoreQuestion.ashx?questionId=" + questionId + "&currentCulture=" + currentCulture,
                type: "POST",
                data: "{}",
                dataType: "text",
                success: function(data, textStatus) {
                    removeContainer(containerId);
                    initTables();
                    return false;
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert('restore not ok: ' + XMLHttpRequest.responseText);
                    initTables();
                    return false;
                }
            });
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            //clearInterval(intervalId);
			alert(XMLHttpRequest.responseText);
            initTables();
        }
    });
}

// Sets a question on hold
function onHoldQuestion(containerId, questionId, isAnswered, isThrown, isOnHold, isAnswering) {
    $.ajax({
        //Check that the question is still in the same status before processing further
    url: "/EPiCode/Netmeeting/Ws/CheckStatus.ashx?questionId=" + questionId + "&isAnswered=" + isAnswered + "&isThrown=" + isThrown + "&isOnHold=" + isOnHold + "&isAnswering=" + isAnswering + "&currentCulture=" + currentCulture,
        type: "POST",
        data: '{}',
        dataType: "text",
        success: function(data, textStatus) {
            $.ajax({
            url: "/EPiCode/Netmeeting/Ws/OnHoldQuestion.ashx?questionId=" + questionId + "&currentCulture=" + currentCulture,
                type: "POST",
                data: "{}",
                dataType: "text",
                success: function(data, textStatus) {
                    removeContainer(containerId);
                    initTables();
                    return false;
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    alert('restore not ok: ' + XMLHttpRequest.responseText);
                    initTables();
                    return false;
                }
            });
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            //clearInterval(intervalId);
			alert(XMLHttpRequest.responseText);
            initTables();
        }
    });
}

//Creates a question and sends it to the db
function createQuestion() {
    var button = this;
    $(button).attr("disabled", "disabled");
    $.ajax({
    url: "/EPiCode/Netmeeting/Ws/CreateQuestion.ashx" + "?currentCulture=" + currentCulture,
        type: "POST",
        data: "netmeetingIdStr=" + netmeetingId + "&strTitle=" + encodeURIComponent($('input.title').val()) + "&strQuestion=" + encodeURIComponent($('textarea.question').val()) + "&strName=" + encodeURIComponent($('input.name').val()),
        dataType: "text",
        success: function(data, textStatus) {
            // Show message and enable button				
            var textContent = $('#ConfirmationText');
            if (textContent != null) {
                // Hide question box and error text
                hideContainer('QuestionBox');
                hideContainer('ErrorText');

                var endText = data.split('|');
                // Empty and fill confirmation text and link
                textContent.empty();
                if (endText.length < 2) {
                    textContent.append(data);
                }
                else {
                    textContent.append(endText[0]);
                    //hid the create questions link and replase it with netmeeting ended text
                    var cont = $('#sendinquestiontonetmeeting');
                    cont.html(endText[1]);
                }
                showContainer('Confirmation');
                showContainer('ConfirmationText');
                showContainer('CloseLink');

                // Clear content in question box
                clearContent('QuestionBox');
                return false;
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            // Show errormessage and enable button
            var textContent = $('#ErrorText');
            if (textContent != null) {
                // Hide ok text and link
                hideContainer('CloseLink');
                hideContainer('ConfirmationText');
                // Show error content and text
                textContent.empty();
                textContent.append(XMLHttpRequest.responseText);
                showContainer('ErrorText');
                showContainer('Confirmation');
            }
        }
    });
	return false;
}