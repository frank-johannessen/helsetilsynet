tinyMCE.addI18n('no.paste_dlg',{
text_title:"Bruk CTRL+V p\u00E5 tastaturet for \u00E5 lime inn i dette vinduet.",
text_linebreaks:"Behold tekstbryting",
word_title:"Bruk CTRL+V p\u00E5 tastaturet for \u00E5 lime inn i dette vinduet."
});