using System.Reflection;


[assembly: AssemblyTitle("EPiServer Page Type Utility")]
[assembly: AssemblyDescription("Utility Library for working with EPiServer Pagetypes")]
[assembly: AssemblyCompany("The EPiServer Community")]
[assembly: AssemblyProduct("EPiCode")]
[assembly: AssemblyCopyright("EPiCode Community Source License - https://www.coderesort.com/p/epicode/wiki/EpicodeLicense")]
[assembly: AssemblyVersion("2.0.*")]
[assembly: AssemblyFileVersion("2.0.0.0")]

