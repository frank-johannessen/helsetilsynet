/*
Copyright � 1997-2003 ElektroPost Stockholm AB. All Rights Reserved.

This code may only be used according to the EPiServer License Agreement.
The use of this code outside the EPiServer environment, in whole or in
parts, is forbidded without prior written permission from ElektroPostf
Stockholm AB.

EPiServer is a registered trademark of ElektroPost Stockholm AB. For
more information see http://www.episerver.com/license or request a
copy of the EPiServer License Agreement by sending an email to info@ep.se
*/

using EPiServer;
namespace Avenir.Templates.Pages
{
	/// <summary>
	/// Summary description for _default.
	/// </summary>
	public partial class Blank : TemplatePage
	{


	}
}
