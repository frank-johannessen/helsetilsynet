﻿/*
Copyright © 1997-2002 ElektroPost Stockholm AB. All Rights Reserved.

This code may only be used according to the EPiServer License Agreement.
The use of this code outside the EPiServer environment, in whole or in
parts, is forbidded without prior written permission from ElektroPost
Stockholm AB.

EPiServer is a registered trademark of ElektroPost Stockholm AB. For
more information see http://www.episerver.com/license or request a
copy of the EPiServer License Agreement by sending an email to info@ep.se
*/
using EPiServer;
using System;
using EPiServer.Core;
//using XhtmlWebControls;
using System.Collections.Generic;


namespace Avenir.Templates.Pages
{
    /// <summary>
    /// Summary description for Page.
    /// </summary>
    public partial class Tilsynssaker : TemplatePage
    {
        
        protected System.Web.UI.WebControls.Label Label1;
        //protected global::EPiServer.Web.WebControls.PageList epiPageList;
        private string addHeading = string.Empty;
        private string scroll = "0"; //indeks i resultatsettet. Listen i skjermbildet vises fra index = scroll
        private string _qYear = string.Empty; 

        /// <summary>
        /// Returns the property Heading if set; otherwise the PageName is returned.
        /// </summary>
        protected string Heading
        {
            get
            {
                if (CurrentPage["Heading"] != null)
                {
                    return CurrentPage.Property["Heading"].ToWebString() + addHeading;
                }
                return CurrentPage.Property["PageName"].ToWebString() + addHeading;
            }
        }


        private void Page_Load(object sender, System.EventArgs e)
        {
            Pager.PagerEvent += Navigasjon;
            Lib.CurrentPage = CurrentPage;
            scroll = Request.QueryString["scroll"];
            //bool searching = true;
            if (String.IsNullOrEmpty(scroll))
            {
                scroll = "0";
                //searching = false;
            }
            
            if (IsPostBack)
            {
                NoShow();       
            }
            else
            {
                Sortby.Items.Add(CurrentPage.Property["SortRelevanceTxt"].ToString());
                Sortby.Items.Add(CurrentPage.Property["SortDateTxt"].ToString());
                Sortby.Items[1].Selected = true;
                //epiPageList.PageLink = CurrentPage.PageLink;
                Lib.CreateCheckboxList(hpKategori, Lib.hpKategoriList());
                Lib.CreateCheckboxList(virksomheter, Lib.virksomheterList());
                Lib.CreateCheckboxList(tYear, Lib.YearList());
                Lib.CreateCheckboxList(reaksjon, Lib.reaksjonList());
                Lib.CreateCheckboxList(tjeneste, Lib.tjenesteList());
                Lib.CreateCheckboxList(vurdering, Lib.vurderingList());

                string qhpKategori = Request.QueryString["helsepersonell"];
                string qvirksomheter = Request.QueryString["virksomheter"];
                string qtYear = Request.QueryString["year"];
                string qreaksjon = Request.QueryString["reaksjonstype"];
                string qtjeneste = Request.QueryString["tjeneste"];
                string qvurdering = Request.QueryString["vurdering"];

                _qYear = Request.QueryString["year"];

                bool queryElement = false;
                if (!String.IsNullOrEmpty(qhpKategori))
                {
                    queryElement = true;
                    Lib.checkCheckboxList(hpKategori, qhpKategori);
                }
                if (!String.IsNullOrEmpty(qvirksomheter))
                {
                    queryElement = true;
                    Lib.checkCheckboxList(virksomheter, qvirksomheter);
                }
                if (!String.IsNullOrEmpty(qtYear))
                {
                    queryElement = true;
                    Lib.checkCheckboxList(tYear, qtYear);
                }
                if (!String.IsNullOrEmpty(qreaksjon))
                {
                    queryElement = true;
                    Lib.checkCheckboxList(reaksjon, qreaksjon);
                }
                if (!String.IsNullOrEmpty(qtjeneste))
                {
                    queryElement = true;
                    Lib.checkCheckboxList(tjeneste, qtjeneste);
                }
                if (!String.IsNullOrEmpty(qvurdering))
                {
                    queryElement = true;
                    Lib.checkCheckboxList(vurdering, qvurdering);
                }
                if (queryElement)
                {
                    NoShow();
                    Button1_Click(null, null);
                }
            }
        }

        private void NoShow()
        {
            //Response.Write(x);
            MainIntro.Visible = false;
            PageBody.Visible = false;
            //this.epiPageList.Visible = false;
        }



        protected string GetPreviewText(PageData page)
        {
            if (page.Property["MainIntro"] != null && page.Property["MainIntro"].ToString().Length > 0)
                return Lib.StripHtml(page.Property["MainIntro"].ToWebString());
            return "";

        }


        protected void Navigasjon(string scr)
        {
            scroll = scr;
            Button1_Click(null, null);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string qry = Sok.Text;
            if (!string.IsNullOrEmpty(qry))
            {
                qry = new Nyno(qry).Query;
            }

            resultHead.Visible = true;
            docQuery g = docQuery.GetDocQuery();
            g.Query = qry;

            // sjekk for synonym
            g.Execute();
            string synonym = g.Synonym;
            if (synonym != null && synonym != string.Empty)
            {
                qry += " OR " + synonym;
                g = docQuery.GetDocQuery();
                g.Query = qry;
            }

            g.AddFasett(new Fasett("dokumenttype", Lib.CreateList("Vedtak tilsynssak")));

            List<string> li = Lib.TestCheckList(hpKategori);
            if (li != null && li.Count != 0) 
                g.AddFasett(new Fasett("hpkategori", li));
            List<string> liCategories = Lib.TestCheckList(virksomheter);
            if (liCategories != null && liCategories.Count != 0)
                g.AddFasett(new Fasett("virksomheter", liCategories));
            List<string> liYear = Lib.TestCheckList(tYear);
            if (liYear != null && liYear.Count != 0)
                g.AddFasett(new Fasett("year", liYear));

            List<string> liRegion = Lib.TestCheckList(reaksjon);
            if (liRegion != null && liRegion.Count != 0)
                g.AddFasett(new Fasett("reaksjon", liRegion));
            List<string> liInstitution = Lib.TestCheckList(tjeneste);
            if (liInstitution != null && liInstitution.Count != 0)
                g.AddFasett(new Fasett("tjeneste", liInstitution));
            List<string> liCountryWide = Lib.TestCheckList(vurdering);
            if (liCountryWide != null && liCountryWide.Count != 0)
                g.AddFasett(new Fasett("vurdering", liCountryWide));
            //g.Query = Sok.Text;
            //g.Keyword = emne;
            g.Scroll = int.Parse(scroll);

            if (Sortby.Items[1].Selected)
            //if (Sortby.SelectedValue == "Date")
                g.SortbyDate = true;

            g.Execute();

            AntallTreff.Text = g.Count.ToString();
            Resultatet.Text = g.Result;

            //more results
            int intScroll = int.Parse(scroll);
            if (g.Count > 10)
            {
                //string url = Request.RawUrl.ToString();
                //int p = url.IndexOf("scroll");     //fjern scroll fra url hvis den finnes.
                //if (p > 0) url = url.Substring(0, p - 1);
                //p = url.IndexOf("?"); //sjekk av vi har et query-element
                //if (p == 0) url += "?z=";
                //string pager = Lib.PagerControl(url, intScroll, (int)g.Count);
                Pager.InitNav(intScroll, (int)g.Count);
                Pager.Visible = true;
            }
            else
                Pager.Visible = false;
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion
    }
}
