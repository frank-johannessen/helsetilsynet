﻿/*
Copyright © 1997-2002 ElektroPost Stockholm AB. All Rights Reserved.

This code may only be used according to the EPiServer License Agreement.
The use of this code outside the EPiServer environment, in whole or in
parts, is forbidded without prior written permission from ElektroPost
Stockholm AB.

EPiServer is a registered trademark of ElektroPost Stockholm AB. For
more information see http://www.episerver.com/license or request a
copy of the EPiServer License Agreement by sending an email to info@ep.se
*/
using EPiServer;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Runtime.Remoting;
using System.Configuration;
using EPiServer.Core;
//using XhtmlWebControls;
using System.Collections.Generic;


namespace Avenir.Templates.Pages
{
    /// <summary>
    /// Summary description for Page.
    /// </summary>
    public partial class Tilsynsrapporter : TemplatePage
    {
        
        protected System.Web.UI.WebControls.Label Label1;
        protected global::EPiServer.Web.WebControls.PageList epiPageList;
        private string addHeading = string.Empty;
        private string scroll = "0"; //indeks i resultatsettet. Listen i skjermbildet vises fra index = scroll
        private string qYear = string.Empty; 

        /// <summary>
        /// Returns the property Heading if set; otherwise the PageName is returned.
        /// </summary>
        protected string Heading
        {
            get
            {
                if (CurrentPage["Heading"] != null)
                {
                    return CurrentPage.Property["Heading"].ToWebString() + addHeading;
                }
                else
                {
                    return CurrentPage.Property["PageName"].ToWebString() + addHeading;
                }
            }
        }


        private void Page_Load(object sender, System.EventArgs e)
        {
            //Response.CacheControl = "no-cache";
            //Response.AddHeader("Pragma", "no-cache");
            //Response.Expires = -1;

            Pager.PagerEvent += new Avenir.Templates.Units.Static.Pager.PagerDelegate(Navigasjon);
            Avenir.Lib.CurrentPage = CurrentPage;
            scroll = Request.QueryString["scroll"];
            //bool searching = true;
            if (String.IsNullOrEmpty(scroll))
            {
                scroll = "0";
                //searching = false;
            }
            
            if (IsPostBack)
            {
                NoShow();       
            }
            else
            {
                Sortby.Items.Add(CurrentPage.Property["SortRelevanceTxt"].ToString());
                Sortby.Items.Add(CurrentPage.Property["SortDateTxt"].ToString());
                Sortby.Items[1].Selected = true;
                //epiPageList.PageLink = CurrentPage.PageLink;
                Lib.CreateCheckboxList(Fylke, Lib.CountyList());
                Lib.CreateCheckboxList(Year, Lib.YearList());
                Lib.CreateCheckboxList(Region, Lib.RegionList());
                Lib.CreateCheckboxList(Institution, Lib.InstitutionList());
                Lib.CreateCheckboxList(CountryWide, Lib.CountrywideList());
                Lib.CreateCheckboxList(Categories, Lib.CategoryList());

                string qFylke = Request.QueryString["fylke"];
                string qLandsomfattende = Request.QueryString["landsomfattende"];

                string qRegion = Request.QueryString["region"];
                string qInstitution = Request.QueryString["helseforetak"];
                string qCountryWide = Request.QueryString["landsomfattende"];
                string qCategories = Request.QueryString["tilsynstemaer"];


                qYear = Request.QueryString["year"];

                bool queryElement = false;
                if (!String.IsNullOrEmpty(qCategories))
                {
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(Categories, qCategories);
                }
                if (!String.IsNullOrEmpty(qCountryWide))
                {
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(CountryWide, qCountryWide);
                }
                if (!String.IsNullOrEmpty(qInstitution))
                {
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(Institution, qInstitution);
                }
                if (!String.IsNullOrEmpty(qRegion))
                {
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(Region, qRegion);
                }
                if (!String.IsNullOrEmpty(qYear))
                {
                    //NoShow();
                    //addHeading = " siste måned ";
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(Year, qYear);
                    //Button1_Click(null, null);
                }
                if (!String.IsNullOrEmpty(qLandsomfattende))
                {
                    //NoShow();
                    //addHeading = " " + qLandsomfattende;
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(CountryWide, qLandsomfattende);
                    //Button1_Click(null, null);
                }
                if (!String.IsNullOrEmpty(qFylke))
                {
                    //NoShow();  
                    //addHeading = " " + qFylke;
                    queryElement = true;
                    Avenir.Lib.checkCheckboxList(Fylke, qFylke);
                    //Button1_Click(null, null);
                }
                if (queryElement)
                {
                    NoShow();
                    Button1_Click(null, null);
                }

            }
        }

        private void NoShow()
        {
            //Response.Write(x);
            this.MainIntro.Visible = false;
            this.PageBody.Visible = false;
            //this.epiPageList.Visible = false;
        }



        protected string GetPreviewText(PageData page)
        {
            if (page.Property["MainIntro"] != null && page.Property["MainIntro"].ToString().Length > 0)
                return Avenir.Lib.StripHtml(page.Property["MainIntro"].ToWebString());
            return "";

        }

 
        protected void Navigasjon(string scr)
        {
            scroll = scr;
            Button1_Click(null, null);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string qry = Sok.Text;
            if (!string.IsNullOrEmpty(qry))
            {
                qry = new Nyno(qry).Query;
            }

            resultHead.Visible = true;
            docQuery g = docQuery.GetDocQuery();
            g.Query = qry;

            // sjekk for synonym
            g.Execute();
            string synonym = g.Synonym;
            if (synonym != null && synonym != string.Empty)
            {
                qry += " OR " + synonym;
                g = docQuery.GetDocQuery();
                g.Query = qry;
            }


            g.AddFasett(new Fasett("dokumenttype", Lib.CreateList("Tilsynsrapport")));

            List<string> li = Avenir.Lib.TestCheckList(Fylke);
            if (li != null && li.Count != 0) 
                g.AddFasett(new Fasett("fylke", li));
            List<string> liYear = Avenir.Lib.TestCheckList(Year);
            if (liYear != null && liYear.Count != 0)
                g.AddFasett(new Fasett("year", liYear));
            if (qYear != string.Empty)
            {
                List<string> y = new List<string>();
                y.Add(qYear);
                g.AddFasett(new Fasett("year", y));
            }
            List<string> liRegion = Avenir.Lib.TestCheckList(Region);
            if (liRegion != null && liRegion.Count != 0)
                g.AddFasett(new Fasett("region", liRegion));
            List<string> liInstitution = Avenir.Lib.TestCheckList(Institution);
            if (liInstitution != null && liInstitution.Count != 0)
                g.AddFasett(new Fasett("institusjon", liInstitution));
            List<string> liCountryWide = Avenir.Lib.TestCheckList(CountryWide);
            if (liCountryWide != null && liCountryWide.Count != 0)
                g.AddFasett(new Fasett("landsomfattende", liCountryWide));
            List<string> liCategories = Avenir.Lib.TestCheckList(Categories);
            if (liCategories != null && liCategories.Count != 0)
                g.AddFasett(new Fasett("kategori", liCategories));
            //g.Keyword = emne;
            g.Scroll = int.Parse(scroll);

            if (Sortby.Items[1].Selected)
            //if (Sortby.SelectedValue == "Date")
                g.SortbyDate = true;

            g.Execute();

            AntallTreff.Text = g.Count.ToString();
            Resultatet.Text = g.Result;

            //more results
            int intScroll = int.Parse(scroll);
            if (g.Count > 10)
            {
                Pager.InitNav(intScroll, (int)g.Count);
                Pager.Visible = true;
            }
            else
                Pager.Visible = false;
        }


        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            // CODEGEN: This call is required by the ASP.NET Web Form Designer.
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion
    }
}