/*
Copyright (c) 2007 EPiServer AB.  All rights reserved.

This code is released by EPiServer AB under the Source Code File - Specific License Conditions, published in 20 August 2007. 
See http://www.episerver.com/Specific_License_Conditions for details. 
*/

using System;
using EPiServer;
using System.Collections.Generic;

namespace Avenir.Templates.Pages
{
	/// <summary>
	/// The search page presents the search result from both the quick search user control
	/// and the search function on this page. The search can be restricted to a page branch by 
	/// setting the "SearchRoot" property.
	/// </summary>
    public partial class SearchPage : TemplatePage
    {
	    private string _scroll = "0"; //indeks i resultatsettet. Listen i skjermbildet vises fra index = scroll

	    protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Pager.PagerEvent += Navigasjon;
            Lib.CurrentPage = CurrentPage;
            Master.NoMenu(); //make menu invisible
            _scroll = Request.QueryString["scroll"];
            if (String.IsNullOrEmpty(_scroll)) _scroll = "0";

            if (!IsPostBack)
            {
                Sortby.Items.Add(CurrentPage.Property["SortRelevanceTxt"].ToString());
                Sortby.Items.Add(CurrentPage.Property["SortDateTxt"].ToString());
                Sortby.Items[1].Selected = true;
                Doctype.Groups = Lib.MakeCheckboxList(Doctype, Avenir.Lib.DocTypeList());
                Lib.CreateCheckboxList(Year, Avenir.Lib.YearList());
                string query = Request.QueryString["quicksearchquery"];
                    Sok.Text = query;
                    Button1_Click(null, null);
            }
        }

 

        protected void Navigasjon(string scr)
        {
            _scroll = scr;
            Button1_Click(null, null);
        }


        private string StripCounting(string s)
        {
            int p = s.IndexOf(" [");
            if (p > -1)
                return s.Substring(0, p);
            return s;
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            string qry = Sok.Text;
            if (!string.IsNullOrEmpty(qry))
            {
                qry = new Nyno(qry).Query;
            }
            docQuery dq = docQuery.GetDocQuery();
            dq.Query = qry;
            if (RemoveReports.Checked)
                dq.AddFasett(new Fasett("-dokumenttype", "Tilsynsrapport"));
            //----OPPTELLING FASETTER P� DOKUMENTTYPE
            dq.Execute();
            // sjekk for synonym
            string synonym = dq.Synonym;
            if (synonym != null && synonym != string.Empty)
            {
                qry += " OR " + synonym;
                dq = docQuery.GetDocQuery();
                dq.Query = qry;
                if (RemoveReports.Checked)
                    dq.AddFasett(new Fasett("-dokumenttype", "Tilsynsrapport"));
                dq.Execute();
            }
            if (dq.Count > 0)
            {
                foreach (System.Web.UI.WebControls.ListItem item in Doctype.Items)
                {
                    dq.RemoveFasetter();
                    if (RemoveReports.Checked)
                        dq.AddFasett(new Fasett("-dokumenttype", "Tilsynsrapport"));
                    dq.AddFasett(new Fasett("dokumenttype", StripCounting(item.Text)));
                    dq.Execute();
                    item.Text = StripCounting(item.Text);
                    if (dq.Count > 0)
                        item.Text = item.Text + " [" + dq.Count + "]";
                    else
                        item.Enabled = false;
                }
                foreach (System.Web.UI.WebControls.ListItem item in Year.Items)
                {
                    dq.RemoveFasetter();
                    if (RemoveReports.Checked)
                        dq.AddFasett(new Fasett("-dokumenttype", "Tilsynsrapport"));
                    dq.AddFasett(new Fasett("year", StripCounting(item.Text)));
                    dq.Execute();
                    item.Text = StripCounting(item.Text);
                    if (dq.Count > 0)
                        item.Text = item.Text + " [" + dq.Count + "]";
                    else
                        item.Enabled = false;
                }
            }
            else
            {
                foreach (System.Web.UI.WebControls.ListItem item in Doctype.Items)
                {
                    item.Text = StripCounting(item.Text);
                    if (Sok.Text != string.Empty)
                        item.Enabled = false;
                }
                foreach (System.Web.UI.WebControls.ListItem item in Year.Items)
                {
                    item.Text = StripCounting(item.Text);
                    if (Sok.Text != string.Empty)
                        item.Enabled = false;
                }
           
            }
            dq.RemoveFasetter();


            List<string> li = Lib.TestCheckList(Doctype);
            if (li != null && li.Count != 0)
                dq.AddFasett(new Fasett("dokumenttype", li));
            if (RemoveReports.Checked)
                dq.AddFasett(new Fasett("-dokumenttype", "Tilsynsrapport"));

            List<string> liYear = Lib.TestCheckList(Year);
            if (liYear != null && liYear.Count != 0)
                dq.AddFasett(new Fasett("year", liYear));

            dq.Scroll = int.Parse(_scroll);
            if (Sortby.Items[1].Selected)
            //if (Sortby.SelectedValue == "Dato")
                dq.SortbyDate = true;

            dq.Execute();
            AntallTreff.Text = dq.Count.ToString();
            Resultatet.Text = dq.Result;


            //more results
            int intScroll = int.Parse(_scroll);
            if (dq.Count > 10)
            {
                Pager.InitNav(intScroll, (int)dq.Count);
                Pager.Visible = true;
            }
            else
                Pager.Visible = false;


        }

        string GetResult(System.Collections.ArrayList ar)
        {
            string s = "<br />";
            foreach (GSALib.GSA.Result searchResult in ar)
            {
                s += Server.HtmlDecode(searchResult.getTitle());
                s += "<br />";
                s += Server.HtmlDecode(searchResult.getUrl());
                s += "<br />";
                s += Server.HtmlDecode(searchResult.getSummary());
                s += "<br />Meta - keywords: " + Server.HtmlDecode(searchResult.getMeta("keywords"));
                s += "<br /><br />";
            }
            return s;
        }



    }
}
