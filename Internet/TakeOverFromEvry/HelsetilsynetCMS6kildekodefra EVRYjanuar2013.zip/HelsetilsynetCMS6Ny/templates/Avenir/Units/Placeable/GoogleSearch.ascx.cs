using EPiServer;

namespace Avenir.Templates.Units.Placeable
{
    public partial class GoogleSearch : UserControlBase
    {
    }
}