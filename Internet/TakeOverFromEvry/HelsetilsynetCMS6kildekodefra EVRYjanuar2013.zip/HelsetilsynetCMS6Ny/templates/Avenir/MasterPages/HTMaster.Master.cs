﻿using Avenir;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EPiServer;
using EPiServer.Core;
using EPiServer.Globalization;
using EPiServer.Configuration;

namespace Avenir.Templates.MasterPages
{
  public partial class HTMaster: System.Web.UI.MasterPage
  {
    public global::System.Web.UI.HtmlControls.HtmlForm Form1;
    private const string _title = "{0}{1}{2}";
    private string _titleSeparator = " - ";
    /// <summary>
    /// Gets or sets the title separator.
    /// </summary>
    public string TitleSeparator
    {
      get { return _titleSeparator; }
      set { _titleSeparator = value; }
    }

    protected string GetLang()
    {
        string s = "no";
        if (CurrentPage.Property["LanguageCode"] != null && CurrentPage.Property["LanguageCode"].ToString() != string.Empty)
           s = CurrentPage.Property["LanguageCode"].ToString();
        return s;
    }

    public void NoMenu()
    {
        this.SubMenu.Visible = false;
    }

    private string mainClass = "";

    protected string GetClass()
    {
        return mainClass;
    }

    public void NoRightColumn()
    {
        mainClass = "noRightColumn";
        //this.main.Attributes.Add("class", "noRightColumn"); 
    }

      
    protected string GetLogotext()
    {
        if (CurrentPage.PageLink == PageReference.StartPage)
            return CurrentPage.Property["LogoAlt1Txt"].ToString();
        return CurrentPage.Property["LogoAlt2Txt"].ToString();
    }

    //protected string getValue(string verdi)
    //{
    //    return CurrentPage.Property[verdi].ToString();
    //}

    protected override void OnLoad(System.EventArgs e)
    {
      base.OnLoad(e);

      if (SubMenu != null && MainMenu != null)
      {
          SubMenu.MenuList = MainMenu.MenuList;
      }
      if (CurrentPage.PageTypeName == "Startsiden")
      {
          SubMenu.Visible = false;
      }
      //if (CurrentPage.ParentLink == new PageReference("10370")) this.SubMenu.Visible = false;

      PageBase page = (PageBase)Page;
      Page.Title = string.Format(_title, page.CurrentPage.Property["PageName"].ToWebString(), TitleSeparator, Settings.Instance.SiteDisplayName);
      if ( page.CurrentPage.Property["PageName"].ToString() == "Emner")
      {
          string emne = "Emne " + StripNumber(Request.QueryString["emne"]);
          Page.Title = string.Format(emne, TitleSeparator, Settings.Instance.SiteDisplayName);
      }

        //this.HtmlElement.Attributes["lang"] = page.CurrentPage.LanguageBranch;
    }

    PageData _currentPage = null;
    public PageData CurrentPage
    {
      get
      {
        if (_currentPage == null)
        {
          _currentPage = FindCurrentPage(this);
        }

        return _currentPage;
      }
    }
    private static PageData FindCurrentPage(Control ctr)
    {
      if (ctr is IPageSource)
      {
        return (ctr as IPageSource).CurrentPage;
      }

      if (ctr.Parent != null)
      {
        return FindCurrentPage(ctr.Parent);
      }

      return null;
    }
    /// <summary>
    /// Enable/Disable Submenu
    /// </summary>
    public bool EnableSubmenu
    {
      set
      {
          if (SubMenu != null)
              SubMenu.Visible = value;
      }
    }
    /// <summary>
    /// Enable/Disable Breadcrumb
    /// </summary>
    public bool EnableBreadcrumbs
    {
      set
      {
        //if (ucBreadcumbs != null)
        //  ucBreadcumbs.Visible = value;
      }
    }
    /// <summary>
    /// Enable/Disable Breadcrumb
    /// </summary>
    public bool EnableHeading
    {
      set
      {
        //if (ucHeading != null)
        //  ucHeading.Visible = value;
      }
    }


    protected string getSitemap()
    {
        PageReference pr = new PageReference(CurrentPage.Property["SiteMap"].ToString());
        PageData pd = DataFactory.Instance.GetPage(pr); 
        return pd.LinkURL;
    }

    protected  string StripNumber(string s)
    {
        int p = s.IndexOf('0');
        if (p > 0)
            return s.Substring(0, p);
        return s;
    }
  }
}
